/****************************************************************************
**
** Copyright (C) 2010 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
** Contact: Nokia Corporation (qt-info@nokia.com)
**
** This file is part of the Qt Mobility Components.
**
** $QT_BEGIN_LICENSE:LGPL$
** Commercial Usage
** Licensees holding valid Qt Commercial licenses may use this file in
** accordance with the Qt Solutions Commercial License Agreement provided
** with the Software or, alternatively, in accordance with the terms
** contained in a written agreement between you and Nokia.
**
** GNU Lesser General Public License Usage
** Alternatively, this file may be used under the terms of the GNU Lesser
** General Public License version 2.1 as published by the Free Software
** Foundation and appearing in the file LICENSE.LGPL included in the
** packaging of this file.  Please review the following information to
** ensure the GNU Lesser General Public License version 2.1 requirements
** will be met: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
** In addition, as a special exception, Nokia gives you certain additional
** rights.  These rights are described in the Nokia Qt LGPL Exception
** version 1.1, included in the file LGPL_EXCEPTION.txt in this package.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 3.0 as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL included in the
** packaging of this file.  Please review the following information to
** ensure the GNU General Public License version 3.0 requirements will be
** met: http://www.gnu.org/copyleft/gpl.html.
**
** Please note Third Party Software included with Qt Solutions may impose
** additional restrictions and it is the user's responsibility to ensure
** that they have met the licensing requirements of the GPL, LGPL, or Qt
** Solutions Commercial license and the relevant license of the Third
** Party Software they are using.
**
** If you are unsure which license is appropriate for your use, please
** contact the sales department at qt-sales@nokia.com.
** $QT_END_LICENSE$
**
****************************************************************************/
// Copyright (c) 2008 Roberto Raggi <roberto.raggi@gmail.com>
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#ifndef CPLUSPLUS_FULLYSPECIFIEDTYPE_H
#define CPLUSPLUS_FULLYSPECIFIEDTYPE_H

#include "CPlusPlusForwardDeclarations.h"


namespace CPlusPlus {

class CPLUSPLUS_EXPORT FullySpecifiedType
{
public:
    FullySpecifiedType(Type *type = 0);
    ~FullySpecifiedType();

    bool isValid() const;
    operator bool() const;

    Type *type() const;
    void setType(Type *type);

    FullySpecifiedType qualifiedType() const;

    bool isConst() const;
    void setConst(bool isConst);

    bool isVolatile() const;
    void setVolatile(bool isVolatile);

    bool isSigned() const;
    void setSigned(bool isSigned);

    bool isUnsigned() const;
    void setUnsigned(bool isUnsigned);

    bool isFriend() const;
    void setFriend(bool isFriend);

    bool isRegister() const;
    void setRegister(bool isRegister);

    bool isStatic() const;
    void setStatic(bool isStatic);

    bool isExtern() const;
    void setExtern(bool isExtern);

    bool isMutable() const;
    void setMutable(bool isMutable);

    bool isTypedef() const;
    void setTypedef(bool isTypedef);

    bool isInline() const;
    void setInline(bool isInline);

    bool isVirtual() const;
    void setVirtual(bool isVirtual);

    bool isExplicit() const;
    void setExplicit(bool isExplicit);

    bool isEqualTo(const FullySpecifiedType &other) const;

    Type &operator*();
    const Type &operator*() const;

    Type *operator->();
    const Type *operator->() const;

    bool operator == (const FullySpecifiedType &other) const;
    bool operator != (const FullySpecifiedType &other) const;
    bool operator < (const FullySpecifiedType &other) const;

    bool match(const FullySpecifiedType &otherTy, TypeMatcher *matcher) const;

    FullySpecifiedType simplified() const;

    void copySpecifiers(const FullySpecifiedType &type);

private:
    Type *_type;
    struct Flags {
        // cv qualifiers
        unsigned _isConst: 1;
        unsigned _isVolatile: 1;

        // sign
        unsigned _isSigned: 1;
        unsigned _isUnsigned: 1;

        // storage class specifiers
        unsigned _isFriend: 1;
        unsigned _isRegister: 1;
        unsigned _isStatic: 1;
        unsigned _isExtern: 1;
        unsigned _isMutable: 1;
        unsigned _isTypedef: 1;

        // function specifiers
        unsigned _isInline: 1;
        unsigned _isVirtual: 1;
        unsigned _isExplicit: 1;
    };
    union {
        unsigned _flags;
        Flags f;
    };
};

} // end of namespace CPlusPlus


#endif // CPLUSPLUS_FULLYSPECIFIEDTYPE_H
