#include "wlancond.h"
#include "maemo_icd.h"
#include "icd/dbus_api.h"
#include "iapconf.h"
#include "iapmonitor.h"

int main(int, char**)
{
    return 0;
}
