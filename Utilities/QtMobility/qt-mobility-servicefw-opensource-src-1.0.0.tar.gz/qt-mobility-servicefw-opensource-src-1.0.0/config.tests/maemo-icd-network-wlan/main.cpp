#include "libicd-network-wlan-dev.h"

int main(int, char**)
{
    return 0;
}
